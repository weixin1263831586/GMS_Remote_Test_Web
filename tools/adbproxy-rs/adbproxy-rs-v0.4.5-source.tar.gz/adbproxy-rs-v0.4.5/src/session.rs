use std::io;
use std::net::SocketAddr;
use std::sync::Arc;

use tokio::io::copy_bidirectional;
use tokio::net::TcpStream;
use tokio::sync::Notify;
use tracing::{debug, warn};

use crate::auth::authenticate_stream;
use crate::config::ReloadableHubPolicy;
use crate::protocol::{
    read_packet, write_fail, write_okay, write_okay_payload, write_packet, write_service,
};
use crate::registry::{DeviceEntry, DeviceRegistry, DeviceSnapshot};

pub struct SessionContext {
    pub registry: DeviceRegistry,
    /// Backend used for host services without a device serial (features, version, …).
    pub default_backend: SocketAddr,
    pub default_pair_code: Option<String>,
    /// Configured backend names in order (local first when enabled).
    pub backend_order: Vec<String>,
    pub kill_notify: Arc<Notify>,
    /// Device/node enable policy (reloaded from config by mtime).
    pub policy: Arc<ReloadableHubPolicy>,
}

/// Handle one adb client connection.
///
/// Policy:
/// - `host:devices` / `track-devices` → answer from aggregated registry
/// - `host:kill` → stop the hub
/// - services that name a serial → rewrite serial if needed, forward whole session
/// - `tport:any` / `transport-any` → prefer local backend, else first backend with a device
/// - everything else → forward whole session to the default backend
pub async fn handle_client(mut client: TcpStream, ctx: SessionContext) -> io::Result<()> {
    let payload = match read_packet(&mut client).await {
        Ok(p) => p,
        Err(err) if err.kind() == io::ErrorKind::UnexpectedEof => return Ok(()),
        Err(err) => return Err(err),
    };

    let service = match String::from_utf8(payload) {
        Ok(s) => s,
        Err(_) => {
            write_fail(&mut client, "invalid utf8 service").await?;
            return Ok(());
        }
    };

    debug!(service = %service, "host service");

    if service == "host:devices" || service == "host:devices-l" {
        let long = service.ends_with("-l");
        let body = client_snapshot(&ctx).await.format_devices(long);
        write_okay_payload(&mut client, body.as_bytes()).await?;
        return Ok(());
    }

    if service == "host:track-devices" || service == "host:track-devices-l" {
        let long = service.ends_with("-l");
        return track_devices(&mut client, &ctx, long).await;
    }

    if service == "host:kill" {
        write_okay(&mut client).await?;
        ctx.kill_notify.notify_waiters();
        return Ok(());
    }

    // Device-info queries without `-s` mean "the one preferred device".
    // Answer from the aggregated registry so we don't forward to an empty
    // local adb while remotes actually have devices (breaks `adb root`, etc.).
    if service == "host:get-state"
        || service == "host:get-serialno"
        || service == "host:get-connection-state"
    {
        let snap = client_snapshot(&ctx).await;
        match pick_preferred(&snap, &ctx.backend_order) {
            Ok(entry) => {
                let body = if service == "host:get-serialno" {
                    entry.public_serial.as_str()
                } else {
                    entry.state.as_str()
                };
                write_okay_payload(&mut client, body.as_bytes()).await?;
            }
            Err(reason) => write_fail(&mut client, &reason).await?,
        }
        return Ok(());
    }

    let snap = client_snapshot(&ctx).await;
    match route_service(
        &service,
        &snap,
        ctx.default_backend,
        ctx.default_pair_code.as_deref(),
        &ctx.backend_order,
    ) {
        Ok((addr, pair_code, upstream_service)) => {
            debug!(%addr, service = %upstream_service, "forwarding to backend");
            forward_session(&mut client, addr, pair_code.as_deref(), &upstream_service).await
        }
        Err(reason) => {
            warn!(service = %service, %reason, "route failed");
            write_fail(&mut client, &reason).await?;
            Ok(())
        }
    }
}

async fn client_snapshot(ctx: &SessionContext) -> DeviceSnapshot {
    let snap = ctx.registry.snapshot().await;
    ctx.policy.refresh().filter_snapshot(snap)
}

/// Decide which backend gets this service and what service string to send upstream.
fn route_service(
    service: &str,
    snap: &DeviceSnapshot,
    default_backend: SocketAddr,
    default_pair_code: Option<&str>,
    backend_order: &[String],
) -> Result<(SocketAddr, Option<String>, String), String> {
    if let Some((entry, upstream)) = rewrite_upstream_service(service, snap, backend_order)? {
        return Ok((entry.backend_addr, entry.pair_code.clone(), upstream));
    }

    // Default: opaque forward to the default backend (local adb or first remote).
    Ok((
        default_backend,
        default_pair_code.map(str::to_string),
        service.to_string(),
    ))
}

/// Resolve a device-scoped host service to `(device entry, rewritten upstream service)`.
///
/// Returns `Ok(None)` for opaque / non-device-scoped services that should use the
/// default backend. Returns `Err` when a named device is missing or offline.
pub fn rewrite_upstream_service<'a>(
    service: &'a str,
    snap: &'a DeviceSnapshot,
    backend_order: &[String],
) -> Result<Option<(&'a DeviceEntry, String)>, String> {
    // Exact transport selectors MUST be checked before `host:transport:` /
    // `host:tport:serial:` prefixes — otherwise `transport-any` becomes serial "any".
    if service == "host:tport:any"
        || service == "host:tport:usb"
        || service == "host:tport:local"
        || service == "host:transport-any"
        || service == "host:transport-usb"
        || service == "host:transport-local"
    {
        let entry = pick_preferred(snap, backend_order)?;
        let upstream = if service.starts_with("host:tport:") {
            format!("host:tport:serial:{}", entry.upstream_serial)
        } else {
            format!("host:transport:{}", entry.upstream_serial)
        };
        return Ok(Some((entry, upstream)));
    }

    if let Some(serial) = service.strip_prefix("host:tport:serial:") {
        let entry = lookup_online(snap, serial)?;
        return Ok(Some((
            entry,
            format!("host:tport:serial:{}", entry.upstream_serial),
        )));
    }

    if let Some(serial) = service.strip_prefix("host:transport:") {
        let entry = lookup_online(snap, serial)?;
        return Ok(Some((
            entry,
            format!("host:transport:{}", entry.upstream_serial),
        )));
    }

    if let Some(rest) = service.strip_prefix("host-serial:") {
        let Some((serial, request)) = rest.split_once(':') else {
            return Err("invalid host-serial service".into());
        };
        let entry = lookup_device(snap, serial)?;
        return Ok(Some((
            entry,
            format!("host-serial:{}:{}", entry.upstream_serial, request),
        )));
    }

    if let Some(request) = service.strip_prefix("host-usb:") {
        let entry = pick_preferred(snap, backend_order)?;
        return Ok(Some((
            entry,
            format!("host-serial:{}:{}", entry.upstream_serial, request),
        )));
    }
    if let Some(request) = service.strip_prefix("host-local:") {
        let entry = pick_preferred(snap, backend_order)?;
        return Ok(Some((
            entry,
            format!("host-serial:{}:{}", entry.upstream_serial, request),
        )));
    }

    if service == "host:features" || service == "host:host-features" {
        if let Ok(entry) = pick_preferred(snap, backend_order) {
            return Ok(Some((entry, service.to_string())));
        }
    }

    // `host:get-state` etc. mean "any single device" (ADB SERVICES.TXT).
    // Rewrite to host-serial on the preferred device so we don't hit an empty
    // default/local backend while remotes have devices.
    if let Some(request) = service.strip_prefix("host:") {
        if matches!(
            request,
            "get-state" | "get-serialno" | "get-devpath" | "get-connection-state"
        ) {
            let entry = pick_preferred(snap, backend_order)?;
            return Ok(Some((
                entry,
                format!("host-serial:{}:{}", entry.upstream_serial, request),
            )));
        }
    }

    Ok(None)
}

/// Public alias used by the multi-user daemon.
pub fn pick_preferred_device<'a>(
    snap: &'a DeviceSnapshot,
    backend_order: &[String],
) -> Result<&'a DeviceEntry, String> {
    pick_preferred(snap, backend_order)
}

fn lookup_device<'a>(snap: &'a DeviceSnapshot, public_serial: &str) -> Result<&'a DeviceEntry, String> {
    snap.find(public_serial)
        .ok_or_else(|| format!("device '{public_serial}' not found"))
}

fn lookup_online<'a>(snap: &'a DeviceSnapshot, public_serial: &str) -> Result<&'a DeviceEntry, String> {
    let entry = lookup_device(snap, public_serial)?;
    if entry.state != "device" {
        return Err(format!("device '{public_serial}' is not online ({})", entry.state));
    }
    Ok(entry)
}

/// Pick a device when the client did not pass `-s`.
///
/// 1. Prefer online devices on the `local` backend.
/// 2. Otherwise walk configured backends in order; use the first with online devices.
/// 3. Within the chosen backend, exactly one online device is required.
fn pick_preferred<'a>(
    snap: &'a DeviceSnapshot,
    backend_order: &[String],
) -> Result<&'a DeviceEntry, String> {
    const LOCAL: &str = "local";

    // Always try local first when it exists in the order list (or in the snap).
    let mut order: Vec<&str> = Vec::new();
    if backend_order.iter().any(|n| n == LOCAL) || snap.devices.iter().any(|d| d.backend_name == LOCAL)
    {
        order.push(LOCAL);
    }
    for name in backend_order {
        if name == LOCAL {
            continue;
        }
        if !order.contains(&name.as_str()) {
            order.push(name.as_str());
        }
    }
    // Fall back to snap order for any backend not listed (shouldn't happen).
    for d in &snap.devices {
        if !order.contains(&d.backend_name.as_str()) {
            order.push(d.backend_name.as_str());
        }
    }

    for name in order {
        match pick_one_on_backend(snap, name) {
            Ok(entry) => return Ok(entry),
            Err(PickBackendErr::None) => continue,
            Err(PickBackendErr::Many) => {
                return Err(format!(
                    "more than one device/emulator on backend '{name}'"
                ));
            }
        }
    }

    Err("no devices/emulators found".into())
}

enum PickBackendErr {
    None,
    Many,
}

fn pick_one_on_backend<'a>(
    snap: &'a DeviceSnapshot,
    backend_name: &str,
) -> Result<&'a DeviceEntry, PickBackendErr> {
    let online: Vec<_> = snap
        .devices
        .iter()
        .filter(|d| d.backend_name == backend_name && d.state == "device")
        .collect();
    match online.len() {
        0 => Err(PickBackendErr::None),
        1 => Ok(online[0]),
        _ => Err(PickBackendErr::Many),
    }
}

async fn forward_session(
    client: &mut TcpStream,
    addr: SocketAddr,
    pair_code: Option<&str>,
    service: &str,
) -> io::Result<()> {
    let mut upstream = match TcpStream::connect(addr).await {
        Ok(s) => s,
        Err(err) => {
            write_fail(client, &format!("backend {addr}: {err}")).await?;
            return Ok(());
        }
    };
    if let Some(code) = pair_code {
        if let Err(err) = authenticate_stream(&mut upstream, code).await {
            write_fail(client, &format!("backend {addr} auth: {err}")).await?;
            return Ok(());
        }
    }
    write_service(&mut upstream, service).await?;
    match copy_bidirectional(client, &mut upstream).await {
        Ok(_) => Ok(()),
        Err(err) if is_benign(&err) => Ok(()),
        Err(err) => {
            warn!(%addr, service, error = %err, "forward pipe error");
            Err(err)
        }
    }
}

async fn track_devices(
    client: &mut TcpStream,
    ctx: &SessionContext,
    long: bool,
) -> io::Result<()> {
    write_okay(client).await?;
    let mut rx = ctx.registry.subscribe();

    let body = client_snapshot(ctx).await.format_devices(long);
    write_packet(client, body.as_bytes()).await?;

    loop {
        match rx.recv().await {
            Ok(()) => {
                let body = client_snapshot(ctx).await.format_devices(long);
                if let Err(err) = write_packet(client, body.as_bytes()).await {
                    if is_benign(&err) {
                        return Ok(());
                    }
                    return Err(err);
                }
            }
            Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => {
                let body = client_snapshot(ctx).await.format_devices(long);
                write_packet(client, body.as_bytes()).await?;
            }
            Err(tokio::sync::broadcast::error::RecvError::Closed) => return Ok(()),
        }
    }
}

fn is_benign(err: &io::Error) -> bool {
    matches!(
        err.kind(),
        io::ErrorKind::BrokenPipe
            | io::ErrorKind::ConnectionReset
            | io::ErrorKind::ConnectionAborted
            | io::ErrorKind::UnexpectedEof
    )
}

#[cfg(test)]
mod route_tests {
    use super::*;
    use crate::registry::DeviceEntry;

    fn snap_one() -> DeviceSnapshot {
        DeviceSnapshot {
            devices: vec![DeviceEntry {
                public_serial: "office:ABC".into(),
                upstream_serial: "ABC".into(),
                state: "device".into(),
                extras: String::new(),
                backend_name: "office".into(),
                backend_addr: "10.0.0.1:5038".parse().unwrap(),
                pair_code: Some("ABCD1234".into()),
                route_id: None,
            }],
        }
    }

    fn order(names: &[&str]) -> Vec<String> {
        names.iter().map(|s| (*s).to_string()).collect()
    }

    #[test]
    fn rewrites_transport_serial() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, code, svc) = route_service(
            "host:transport:office:ABC",
            &snap_one(),
            default,
            None,
            &order(&["office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(code.as_deref(), Some("ABCD1234"));
        assert_eq!(svc, "host:transport:ABC");
    }

    #[test]
    fn rewrites_tport_serial() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, _, svc) = route_service(
            "host:tport:serial:office:ABC",
            &snap_one(),
            default,
            None,
            &order(&["office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(svc, "host:tport:serial:ABC");
    }

    #[test]
    fn tport_any_becomes_serial() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, _, svc) = route_service(
            "host:tport:any",
            &snap_one(),
            default,
            None,
            &order(&["local", "office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(svc, "host:tport:serial:ABC");
    }

    #[test]
    fn tport_any_prefers_local_even_if_remotes_exist() {
        let snap = DeviceSnapshot {
            devices: vec![
                DeviceEntry {
                    public_serial: "LOCAL1".into(),
                    upstream_serial: "LOCAL1".into(),
                    state: "device".into(),
                    extras: String::new(),
                    backend_name: "local".into(),
                    backend_addr: "127.0.0.1:5039".parse().unwrap(),
                    pair_code: None,
                    route_id: None,
                },
                DeviceEntry {
                    public_serial: "REMOTE1".into(),
                    upstream_serial: "REMOTE1".into(),
                    state: "device".into(),
                    extras: String::new(),
                    backend_name: "office".into(),
                    backend_addr: "10.0.0.1:5038".parse().unwrap(),
                    pair_code: Some("ABCD1234".into()),
                    route_id: None,
                },
            ],
        };
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, code, svc) = route_service(
            "host:tport:any",
            &snap,
            default,
            None,
            &order(&["local", "office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "127.0.0.1:5039");
        assert!(code.is_none());
        assert_eq!(svc, "host:tport:serial:LOCAL1");
    }

    #[test]
    fn tport_any_falls_back_to_first_remote_with_device() {
        let snap = DeviceSnapshot {
            devices: vec![
                DeviceEntry {
                    public_serial: "REMOTE1".into(),
                    upstream_serial: "REMOTE1".into(),
                    state: "device".into(),
                    extras: String::new(),
                    backend_name: "office".into(),
                    backend_addr: "10.0.0.1:5038".parse().unwrap(),
                    pair_code: Some("CODE1111".into()),
                    route_id: None,
                },
                DeviceEntry {
                    public_serial: "REMOTE2".into(),
                    upstream_serial: "REMOTE2".into(),
                    state: "device".into(),
                    extras: String::new(),
                    backend_name: "lab".into(),
                    backend_addr: "10.0.0.2:5038".parse().unwrap(),
                    pair_code: Some("CODE2222".into()),
                    route_id: None,
                },
            ],
        };
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, code, svc) = route_service(
            "host:transport-any",
            &snap,
            default,
            None,
            &order(&["local", "office", "lab"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(code.as_deref(), Some("CODE1111"));
        assert_eq!(svc, "host:transport:REMOTE1");
    }

    #[test]
    fn tport_any_errors_when_local_has_many() {
        let snap = DeviceSnapshot {
            devices: vec![
                DeviceEntry {
                    public_serial: "L1".into(),
                    upstream_serial: "L1".into(),
                    state: "device".into(),
                    extras: String::new(),
                    backend_name: "local".into(),
                    backend_addr: "127.0.0.1:5039".parse().unwrap(),
                    pair_code: None,
                    route_id: None,
                },
                DeviceEntry {
                    public_serial: "L2".into(),
                    upstream_serial: "L2".into(),
                    state: "device".into(),
                    extras: String::new(),
                    backend_name: "local".into(),
                    backend_addr: "127.0.0.1:5039".parse().unwrap(),
                    pair_code: None,
                    route_id: None,
                },
            ],
        };
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let err = route_service(
            "host:tport:any",
            &snap,
            default,
            None,
            &order(&["local"]),
        )
        .unwrap_err();
        assert!(err.contains("more than one"));
    }

    #[test]
    fn transport_any_not_parsed_as_serial_any() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, code, svc) = route_service(
            "host:transport-any",
            &snap_one(),
            default,
            None,
            &order(&["office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(code.as_deref(), Some("ABCD1234"));
        assert_eq!(svc, "host:transport:ABC");
    }

    #[test]
    fn transport_usb_and_local_use_preferred() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let o = order(&["office"]);
        let (_, _, usb) =
            route_service("host:transport-usb", &snap_one(), default, None, &o).unwrap();
        let (_, _, local) =
            route_service("host:transport-local", &snap_one(), default, None, &o).unwrap();
        assert_eq!(usb, "host:transport:ABC");
        assert_eq!(local, "host:transport:ABC");
    }

    #[test]
    fn host_usb_request_rewrites_to_host_serial() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, _, svc) = route_service(
            "host-usb:get-state",
            &snap_one(),
            default,
            None,
            &order(&["office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(svc, "host-serial:ABC:get-state");
    }

    #[test]
    fn tport_usb_uses_preferred() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (_, _, svc) = route_service(
            "host:tport:usb",
            &snap_one(),
            default,
            None,
            &order(&["office"]),
        )
        .unwrap();
        assert_eq!(svc, "host:tport:serial:ABC");
    }

    #[test]
    fn features_follows_preferred_device_backend() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, code, svc) = route_service(
            "host:features",
            &snap_one(),
            default,
            Some("LOCALCODE"),
            &order(&["local", "office"]),
        )
        .unwrap();
        // Prefer office (has the only online device) over empty local default.
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(code.as_deref(), Some("ABCD1234"));
        assert_eq!(svc, "host:features");
    }

    #[test]
    fn get_state_rewrites_to_preferred_host_serial() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let (addr, code, svc) = route_service(
            "host:get-state",
            &snap_one(),
            default,
            None,
            &order(&["local", "office"]),
        )
        .unwrap();
        assert_eq!(addr.to_string(), "10.0.0.1:5038");
        assert_eq!(code.as_deref(), Some("ABCD1234"));
        assert_eq!(svc, "host-serial:ABC:get-state");
    }

    #[test]
    fn get_state_errors_when_no_devices() {
        let default: SocketAddr = "127.0.0.1:5039".parse().unwrap();
        let err = route_service(
            "host:get-state",
            &DeviceSnapshot { devices: vec![] },
            default,
            None,
            &order(&["local"]),
        )
        .unwrap_err();
        assert!(err.contains("no devices"));
    }
}
