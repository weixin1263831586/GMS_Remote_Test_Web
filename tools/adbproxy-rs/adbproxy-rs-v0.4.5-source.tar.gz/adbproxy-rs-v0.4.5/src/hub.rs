use std::future::Future;
use std::io;
use std::sync::Arc;

use thiserror::Error;
use tokio::net::TcpListener;
use tokio::sync::Notify;
use tracing::{debug, error, info, warn};

use crate::backend::{fetch_server_version, run_backend_poller};
use crate::config::{BackendConfig, HubConfig, ReloadableHubPolicy};
use crate::local::LocalAdb;
use crate::registry::DeviceRegistry;
use crate::session::{handle_client, SessionContext};

#[derive(Debug, Error)]
pub enum HubError {
    #[error("io error: {0}")]
    Io(#[from] io::Error),

    #[error(
        "failed to bind {addr}: {source}. If a local adb server is running, stop it first with `adb kill-server`"
    )]
    Bind {
        addr: std::net::SocketAddr,
        #[source]
        source: io::Error,
    },

    #[error("local adb server error: {0}")]
    LocalAdb(io::Error),
}

pub type Result<T> = std::result::Result<T, HubError>;

pub async fn run_hub(config: HubConfig) -> Result<()> {
    run_hub_with_shutdown(config, std::future::pending::<()>()).await
}

pub async fn run_hub_with_shutdown(
    mut config: HubConfig,
    shutdown: impl Future<Output = ()>,
) -> Result<()> {
    let policy = Arc::new(ReloadableHubPolicy::from_config(&config));

    // Keep LocalAdb alive for the hub lifetime so Drop can kill the side server.
    let _local_adb = if config.include_local {
        let local = LocalAdb::prepare(config.local_adb_port)
            .await
            .map_err(HubError::LocalAdb)?;
        // Match the real adb server's ADB_SERVER_VERSION so clients don't kill us.
        match fetch_server_version(local.addr, None).await {
            Ok(v) => {
                info!(adb_version = v, "synced hub version from local adb server");
                config.adb_version = v;
            }
            Err(err) => {
                warn!(error = %err, "could not read local adb version; using configured value");
            }
        }
        let local_backend = BackendConfig {
            name: LocalAdb::backend_name().to_string(),
            addr: local.addr,
            pair_code: None,
            enabled: true,
        };
        config
            .backends
            .retain(|b| b.name != local_backend.name && b.addr != local_backend.addr);
        config.backends.insert(0, local_backend);
        Some(local)
    } else {
        None
    };

    // Only poll / route through enabled backends (local always enabled above).
    config.backends.retain(|b| b.enabled);

    if config.backends.is_empty() {
        return Err(HubError::Io(io::Error::new(
            io::ErrorKind::InvalidInput,
            "no backends configured (all nodes disabled?)",
        )));
    }

    let default_backend = config.backends[0].addr;
    let default_pair_code = config.backends[0].pair_code.clone();
    let backend_order: Vec<String> = config.backends.iter().map(|b| b.name.clone()).collect();
    let registry = DeviceRegistry::new();
    let kill_notify = Arc::new(Notify::new());

    // Populate registry BEFORE binding so wait_for_port / early clients never see
    // an empty snapshot and return "no devices".
    crate::backend::poll_backends_once(&config, &registry).await;

    let listener = TcpListener::bind(config.listen)
        .await
        .map_err(|source| HubError::Bind {
            addr: config.listen,
            source,
        })?;

    info!(
        version = crate::VERSION,
        listen = %config.listen,
        backends = config.backends.len(),
        include_local = config.include_local,
        "adb-hub {} listening",
        crate::VERSION
    );
    for b in &config.backends {
        info!(name = %b.name, addr = %b.addr, "backend configured");
    }

    let poller_config = config.clone();
    let poller_registry = registry.clone();
    let poller = tokio::spawn(async move {
        run_backend_poller(poller_config, poller_registry).await;
    });

    tokio::pin!(shutdown);

    loop {
        tokio::select! {
            _ = &mut shutdown => {
                info!("shutdown signal received");
                poller.abort();
                return Ok(());
            }
            _ = kill_notify.notified() => {
                info!("host:kill received");
                poller.abort();
                return Ok(());
            }
            accepted = listener.accept() => {
                let (client, client_addr) = accepted?;
                debug!(client = %client_addr, "client connected");
                let ctx = SessionContext {
                    registry: registry.clone(),
                    default_backend,
                    default_pair_code: default_pair_code.clone(),
                    backend_order: backend_order.clone(),
                    kill_notify: kill_notify.clone(),
                    policy: policy.clone(),
                };
                tokio::spawn(async move {
                    if let Err(err) = handle_client(client, ctx).await {
                        if is_benign(&err) {
                            debug!(client = %client_addr, error = %err, "client disconnected");
                        } else {
                            error!(client = %client_addr, error = %err, "client session failed");
                        }
                    }
                });
            }
        }
    }
}

fn is_benign(err: &io::Error) -> bool {
    matches!(
        err.kind(),
        io::ErrorKind::BrokenPipe
            | io::ErrorKind::ConnectionReset
            | io::ErrorKind::ConnectionAborted
            | io::ErrorKind::UnexpectedEof
    )
}
