use std::future::Future;
use std::io;
use std::sync::Arc;

use thiserror::Error;
use tokio::net::TcpListener;
use tokio::sync::Notify;
use tracing::{debug, error, info, warn};

use crate::backend::{fetch_server_version, run_backend_poller};
use crate::config::{BackendConfig, HubConfig, ReloadableHubPolicy};
use crate::local::LocalAdb;
use crate::registry::DeviceRegistry;
use crate::session::{handle_client, SessionContext};

#[derive(Debug, Error)]
pub enum HubError {
    #[error("io error: {0}")]
    Io(#[from] io::Error),

    #[error(
        "failed to bind {addr}: {source}. If a local adb server is running, stop it first with `adb kill-server`"
    )]
    Bind {
        addr: std::net::SocketAddr,
        #[source]
        source: io::Error,
    },

    #[error("local adb server error: {0}")]
    LocalAdb(io::Error),
}

pub type Result<T> = std::result::Result<T, HubError>;

pub async fn run_hub(config: HubConfig) -> Result<()> {
    run_hub_with_shutdown(config, std::future::pending::<()>()).await
}

pub async fn run_hub_with_shutdown(
    config: HubConfig,
    shutdown: impl Future<Output = ()>,
) -> Result<()> {
    run_hub_with_shutdown_options(config, false, shutdown).await
}

pub async fn run_hub_with_shutdown_options(
    mut config: HubConfig,
    ignore_host_kill: bool,
    shutdown: impl Future<Output = ()>,
) -> Result<()> {
    // Reserve the public ADB port before starting the side server or polling
    // remote backends. Otherwise another `adb` invocation can auto-start the
    // stock server on :5037 during initialization and make the hub exit with
    // EADDRINUSE after it has already discovered every backend.
    let listener = bind_listener(&config).await?;
    let policy = Arc::new(ReloadableHubPolicy::from_config(&config));

    // Keep LocalAdb alive for the hub lifetime so Drop can kill the side server.
    let _local_adb = if config.include_local {
        let local = LocalAdb::prepare_side(config.local_adb_port)
            .await
            .map_err(HubError::LocalAdb)?;
        // Match the real adb server's ADB_SERVER_VERSION so clients don't kill us.
        match fetch_server_version(local.addr, None).await {
            Ok(v) => {
                info!(adb_version = v, "synced hub version from local adb server");
                config.adb_version = v;
            }
            Err(err) => {
                warn!(error = %err, "could not read local adb version; using configured value");
            }
        }
        let local_backend = BackendConfig {
            name: LocalAdb::backend_name().to_string(),
            addr: local.addr,
            pair_code: None,
            enabled: true,
        };
        config
            .backends
            .retain(|b| b.name != local_backend.name && b.addr != local_backend.addr);
        config.backends.insert(0, local_backend);
        Some(local)
    } else {
        None
    };

    // Only poll / route through enabled backends (local always enabled above).
    config.backends.retain(|b| b.enabled);

    if config.backends.is_empty() {
        return Err(HubError::Io(io::Error::new(
            io::ErrorKind::InvalidInput,
            "no backends configured (all nodes disabled?)",
        )));
    }

    let default_backend = config.backends[0].addr;
    let default_pair_code = config.backends[0].pair_code.clone();
    let backend_order: Vec<String> = config.backends.iter().map(|b| b.name.clone()).collect();
    let registry = DeviceRegistry::new();
    let kill_notify = Arc::new(Notify::new());

    // Populate the registry before accepting clients so an early inventory
    // request never sees an empty snapshot.
    crate::backend::poll_backends_once(&config, &registry).await;

    info!(
        version = crate::VERSION,
        listen = %config.listen,
        backends = config.backends.len(),
        include_local = config.include_local,
        "adb-hub {} listening",
        crate::VERSION
    );
    for b in &config.backends {
        info!(name = %b.name, addr = %b.addr, "backend configured");
    }

    let poller_config = config.clone();
    let poller_registry = registry.clone();
    let poller = tokio::spawn(async move {
        run_backend_poller(poller_config, poller_registry).await;
    });

    tokio::pin!(shutdown);

    loop {
        tokio::select! {
            _ = &mut shutdown => {
                info!("shutdown signal received");
                poller.abort();
                return Ok(());
            }
            _ = kill_notify.notified() => {
                if ignore_host_kill {
                    info!("host:kill ignored (managed single-user hub stays up)");
                    continue;
                }
                info!("host:kill received");
                poller.abort();
                return Ok(());
            }
            accepted = listener.accept() => {
                let (client, client_addr) = accepted?;
                debug!(client = %client_addr, "client connected");
                let ctx = SessionContext {
                    registry: registry.clone(),
                    default_backend,
                    default_pair_code: default_pair_code.clone(),
                    backend_order: backend_order.clone(),
                    kill_notify: kill_notify.clone(),
                    policy: policy.clone(),
                };
                tokio::spawn(async move {
                    if let Err(err) = handle_client(client, ctx).await {
                        if is_benign(&err) {
                            debug!(client = %client_addr, error = %err, "client disconnected");
                        } else {
                            error!(client = %client_addr, error = %err, "client session failed");
                        }
                    }
                });
            }
        }
    }
}

async fn bind_listener(config: &HubConfig) -> Result<TcpListener> {
    // The stock ADB server normally owns :5037. Stop it and immediately claim
    // the port. Retrying closes the small stop/bind window if another local
    // process invokes `adb` at exactly the same time.
    if config.include_local && config.listen.port() == 5037 {
        let mut last_in_use = None;
        for _ in 0..5 {
            LocalAdb::stop_default().await.map_err(HubError::LocalAdb)?;
            match TcpListener::bind(config.listen).await {
                Ok(listener) => return Ok(listener),
                Err(source) if source.kind() == io::ErrorKind::AddrInUse => {
                    last_in_use = Some(source);
                }
                Err(source) => {
                    return Err(HubError::Bind {
                        addr: config.listen,
                        source,
                    });
                }
            }
        }
        return Err(HubError::Bind {
            addr: config.listen,
            source: last_in_use.expect("bind retry records address-in-use"),
        });
    }

    TcpListener::bind(config.listen)
        .await
        .map_err(|source| HubError::Bind {
            addr: config.listen,
            source,
        })
}

fn is_benign(err: &io::Error) -> bool {
    matches!(
        err.kind(),
        io::ErrorKind::BrokenPipe
            | io::ErrorKind::ConnectionReset
            | io::ErrorKind::ConnectionAborted
            | io::ErrorKind::UnexpectedEof
    )
}
