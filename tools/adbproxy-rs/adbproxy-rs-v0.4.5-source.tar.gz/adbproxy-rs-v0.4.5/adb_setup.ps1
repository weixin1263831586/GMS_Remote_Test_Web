# Install adb-hub + adb-proxy from GitHub Releases and write client config.
# Does not replace the official adb binary.
#
# Usage:
#   .\adb_setup.ps1                 # download + install, then interactive config
#   .\adb_setup.ps1 -Install        # download + install only
#   .\adb_setup.ps1 -Config         # interactive config only
#   .\adb_setup.ps1 -Version 0.4.4  # pin a release tag (with or without leading v)
#   .\adb_setup.ps1 -UninstallWrapper  # remove legacy PATH wrapper
#
# Environment:
#   $env:ADB_PROXY_INSTALL_DIR   Install directory (default: $HOME\.local\bin)
#   $env:ADB_PROXY_REPO          GitHub repo (default: Ken-u/adbproxy-rs)
#   $env:ADB_SETUP_SKIP_DOWNLOAD=1   Skip download (tests / offline config)
[CmdletBinding()]
param(
    [switch]$Install,
    [switch]$Config,
    [switch]$UninstallWrapper,
    [string]$Version = '',
    [switch]$Help
)

$ErrorActionPreference = 'Stop'

$script:Repo         = if ($env:ADB_PROXY_REPO) { $env:ADB_PROXY_REPO } else { 'Ken-u/adbproxy-rs' }
$script:InstallDir   = if ($env:ADB_PROXY_INSTALL_DIR) { $env:ADB_PROXY_INSTALL_DIR } else { Join-Path $HOME '.local\bin' }
$script:ConfigDir    = Join-Path $env:APPDATA 'adb-hub'
$script:ConfigFile   = Join-Path $script:ConfigDir 'config.toml'
$script:LegacyConfig = Join-Path $HOME '.adbproxy'
$script:ApiBase      = "https://api.github.com/repos/$($script:Repo)"
$script:ReleaseBase  = "https://github.com/$($script:Repo)/releases/download"
$script:WrapperMarker = '# adb-wrapper'
$script:RequestedVersion = $Version

function Show-Help {
    Write-Host @"
adb-proxy / adb-hub setup

Downloads a GitHub release for this OS/arch (latest by default), installs
adb-hub and adb-proxy into $InstallDir, and optionally writes client config.

Usage:
  .\adb_setup.ps1                 Download+install, then interactive config
  .\adb_setup.ps1 -Install        Download+install only
  .\adb_setup.ps1 -Config         Interactive config only
  .\adb_setup.ps1 -Version <tag>  Use release tag (with or without leading v)
  .\adb_setup.ps1 -UninstallWrapper
                                  Remove legacy PATH wrapper
  .\adb_setup.ps1 -Help

Examples:
  .\adb_setup.ps1 -Install -Version 0.4.4
  .\adb_setup.ps1 -Version v0.4.3

Environment:
  `$env:ADB_PROXY_INSTALL_DIR   Install directory (default: `$HOME\.local\bin)
  `$env:ADB_PROXY_REPO          GitHub repo (default: Ken-u/adbproxy-rs)
  `$env:ADB_SETUP_SKIP_DOWNLOAD=1   Skip download (tests / offline config)
"@
}

function Test-Host([string]$h) { -not [string]::IsNullOrWhiteSpace($h) }
function Test-Port([string]$p) {
    $n = 0
    [int]::TryParse($p, [ref]$n) -and $n -ge 1 -and $n -le 65535
}
function Test-Name([string]$n) {
    -not [string]::IsNullOrWhiteSpace($n) -and $n -notmatch '[\s=]'
}

function Fetch-LatestTag {
    $resp = Invoke-RestMethod -Uri "$($script:ApiBase)/releases/latest" -Headers @{ 'User-Agent' = 'adb_setup.ps1' }
    if (-not $resp.tag_name) {
        throw "could not parse latest release tag from GitHub."
    }
    return $resp.tag_name
}

function Normalize-ReleaseTag([string]$v) {
    $v = $v.Trim()
    if ($v.StartsWith('v') -or $v.StartsWith('V')) {
        $v = $v.Substring(1)
    }
    if ([string]::IsNullOrWhiteSpace($v)) {
        throw "empty version."
    }
    return "v$v"
}

function Resolve-ReleaseTag {
    if (-not [string]::IsNullOrWhiteSpace($script:RequestedVersion)) {
        return Normalize-ReleaseTag $script:RequestedVersion
    }
    return Fetch-LatestTag
}

function Download-And-Install {
    $archive = 'adb-proxy-windows-x86_64.tar.gz'
    $tag     = Resolve-ReleaseTag
    $url     = "$script:ReleaseBase/$tag/$archive"

    Write-Host "Installing adb-hub + adb-proxy $tag"
    Write-Host "  archive: $archive"
    Write-Host "  from:    $url"
    Write-Host "  into:    $script:InstallDir"

    New-Item -ItemType Directory -Force -Path $script:InstallDir | Out-Null
    $tmp = New-Item -ItemType Directory -Path (Join-Path $env:TEMP "adb_setup_$(Get-Random)")
    try {
        $archivePath = Join-Path $tmp $archive
        try {
            Invoke-WebRequest -Uri $url -OutFile $archivePath -UseBasicParsing
        } catch {
            throw "failed to download $url — check that release tag '$tag' exists for $($script:Repo). $_"
        }

        $staging = Join-Path $tmp 'extract'
        New-Item -ItemType Directory -Path $staging | Out-Null
        # Windows tar reads .tar.gz natively
        tar -xzf $archivePath -C $staging
        if ($LASTEXITCODE -ne 0) { throw "tar extraction failed (exit $LASTEXITCODE). Is tar available?" }

        foreach ($bin in 'adb-hub', 'adb-proxy') {
            $src = Join-Path $staging "$bin.exe"
            $dst = Join-Path $script:InstallDir "$bin.exe"
            if (-not (Test-Path $src)) {
                Write-Error "archive missing $bin.exe"
                Get-ChildItem $staging | Format-Table
                throw "missing $bin.exe"
            }
            Copy-Item $src $dst -Force
            Write-Host "Installed $dst"
        }

        Ensure-PathHint
    }
    finally {
        Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
    }
}

function Ensure-PathHint {
    $pathUser = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($pathUser -and ($pathUser.Split(';') -contains $script:InstallDir)) { return }

    Write-Host ""
    Write-Host "NOTE: $($script:InstallDir) is not in your user PATH."
    if (-not $Host.UI.RawUI.WindowTitle -or -not [Environment]::UserInteractive) {
        Write-Host "Add this manually:"
        Write-Host "  [Environment]::SetEnvironmentVariable('Path', `"$($script:InstallDir);`$([Environment]::GetEnvironmentVariable('Path','User'))`", 'User')"
        return
    }

    $ans = Read-Host "Append $($script:InstallDir) to user PATH? [Y/n]"
    if ($ans -match '^(n|no)$') { return }
    $newPath = if ($pathUser) { "$($script:InstallDir);$pathUser" } else { $script:InstallDir }
    [Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
    Write-Host "Appended to user PATH — open a new terminal for it to take effect."
}

function Write-TomlConfig([string]$Name, [string]$Host_, [string]$Port) {
    New-Item -ItemType Directory -Force -Path $script:ConfigDir | Out-Null
    @"
listen = "127.0.0.1:5037"
poll_interval_ms = 1000
include_local = true
local_adb_port = 5039

[[backend]]
name = "$Name"
addr = "${Host_}:$Port"
"@ | Set-Content -Path $script:ConfigFile -Encoding UTF8
    Write-Host "Wrote $($script:ConfigFile)"
}

function Prompt-And-Save {
    $defaultName  = 'remote'
    $defaultHost  = ''
    $defaultPort  = '5038'

    if (Test-Path $script:LegacyConfig) {
        foreach ($line in Get-Content $script:LegacyConfig) {
            if ($line -match '^\s*host\s*=\s*(.+?)\s*$') { $defaultHost = $Matches[1].Trim() }
            elseif ($line -match '^\s*port\s*=\s*(.+?)\s*$') { $defaultPort = $Matches[1].Trim() }
        }
    }

    $name = $null
    while ($true) {
        $prompt = if ($defaultName) { "Backend name [$defaultName]" } else { "Backend name" }
        $name = (Read-Host $prompt)
        if (-not $name) { $name = $defaultName }
        if (Test-Name $name) { break }
        Write-Host "Error: name must be non-empty and must not contain spaces or '='." -ForegroundColor Red
    }

    $host_ = $null
    while ($true) {
        if ($defaultHost) {
            $host_ = Read-Host "Remote adb-proxy host [$defaultHost]"
            if (-not $host_) { $host_ = $defaultHost }
        } else {
            $host_ = Read-Host "Remote adb-proxy host"
        }
        if (Test-Host $host_) { break }
        Write-Host "Error: host is required." -ForegroundColor Red
        $defaultHost = ''
    }

    $port = $null
    while ($true) {
        $port = Read-Host "Remote adb-proxy port [$defaultPort]"
        if (-not $port) { $port = $defaultPort }
        if (Test-Port $port) { break }
        Write-Host "Error: port must be 1-65535." -ForegroundColor Red
    }

    Write-TomlConfig $name $host_ $port
}

function Print-NextSteps {
    $hub   = Join-Path $script:InstallDir 'adb-hub.exe'
    $proxy = Join-Path $script:InstallDir 'adb-proxy.exe'
    Write-Host @"

Done.

Client (this machine):
  adb kill-server
  $hub --config $($script:ConfigFile)
  adb devices

Device host (USB machine):
  adb start-server
  $proxy --listen 0.0.0.0:5038 --target 127.0.0.1:5037

Re-run install only:   .\adb_setup.ps1 -Install
Install a version:     .\adb_setup.ps1 -Install -Version 0.4.4
Config only:           .\adb_setup.ps1 -Config
Remove old wrapper:    .\adb_setup.ps1 -UninstallWrapper
"@
}

function Test-IsWrapperAdb([string]$Path) {
    if (-not (Test-Path $Path)) { return $false }
    $lines = Get-Content $Path -TotalCount 5 -ErrorAction SilentlyContinue
    if (-not $lines) { return $false }
    foreach ($line in $lines) {
        if ($line -and $line.Contains($script:WrapperMarker)) { return $true }
    }
    return $false
}

function Resolve-Executable([string]$Path) {
    if (-not (Test-Path $Path)) { return $null }
    $fi = Get-Item $Path
    while ($fi.LinkType -eq 'SymbolicLink') {
        $target = if ($fi.Target) { $fi.Target[0] } else { $null }
        if (-not $target) { break }
        $fi = Get-Item $target
    }
    if (-not $fi -or -not $fi.PSIsContainer -and -not $fi.Length) { return $null }
    return $fi.FullName
}

function Uninstall-OldWrapper {
    $adbCmd = Get-Command adb -ErrorAction SilentlyContinue
    if (-not $adbCmd) {
        Write-Host "adb not found in PATH; nothing to uninstall."
        return
    }
    $resolved = Resolve-Executable $adbCmd.Source
    if (-not $resolved) {
        throw "cannot resolve adb at $($adbCmd.Source)"
    }
    if (-not (Test-IsWrapperAdb $resolved)) {
        Write-Host "Current adb is not an adb-wrapper; nothing to uninstall."
        return
    }

    $adbDir   = Split-Path $resolved -Parent
    $wrapped  = Join-Path $adbDir 'wrapper\adb.exe'
    if (-not (Test-Path $wrapped)) {
        throw "original adb not found at $wrapped"
    }
    if (Test-IsWrapperAdb $wrapped) {
        throw "$wrapped is also a wrapper; refusing to uninstall."
    }

    Copy-Item $wrapped $resolved -Force
    Remove-Item $wrapped -Force
    $wrapperDir = Join-Path $adbDir 'wrapper'
    if (Test-Path $wrapperDir) {
        Remove-Item $wrapperDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-Host "Restored original adb to $resolved"
}

function Invoke-Main {
    if ($Help) { Show-Help; return }

    if ($UninstallWrapper) {
        Uninstall-OldWrapper
    }
    elseif ($Install) {
        Download-And-Install
    }
    elseif ($Config) {
        Prompt-And-Save
        Print-NextSteps
    }
    else {
        if ($env:ADB_SETUP_SKIP_DOWNLOAD -ne '1') {
            Download-And-Install
            Write-Host ""
        }
        Prompt-And-Save
        Print-NextSteps
    }
}

# Run only when executed directly, not when dot-sourced (allows testing).
# When dot-sourced, $MyInvocation.InvocationName is '.'; when run directly
# it is the script path.
if ($MyInvocation.InvocationName -ne '.') {
    Invoke-Main
}
