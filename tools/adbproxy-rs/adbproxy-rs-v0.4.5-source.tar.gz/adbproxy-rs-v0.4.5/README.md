# adb-proxy / adb-hub

This repository provides two user-facing binaries:

1. **`adb-proxy`** — TCP proxy on the machine that has USB devices (pair-code auth required)
2. **`adb-hub`** — local hub for stock `adb` (`127.0.0.1:5037`): USB + remote `adb-proxy` backends

`adb-hubd` is a compatibility alias for `adb-hub --daemon`.

```text
Client PC                         Device hosts
---------                         ------------
official adb
    |
    v
adb-hub :5037  ----TCP---->  adb-proxy :5038  -->  adb server :5037  --> USB
               ----TCP---->  adb-proxy :5038  -->  adb server :5037  --> USB
```

`adb-hub` speaks just enough of the ADB host protocol to merge device lists. Other host services (`features`, `version`, `tport`, `transport`, …) are forwarded as-is to the owning backend (or the default/local adb server).

Remote `adb-proxy` instances require an 8-character pair code (`A-Z0-9`) on every connection. The port may be open on the LAN, but ADB traffic is rejected until the hub authenticates with the matching code. `adb-hub` also checks the remote `adb-proxy` version (`proxy:version`); backends older than the hub's minimum are skipped and `pair` prints an upgrade hint.

On Linux shared hosts, the same commands work for every OS user: the first `adb-hub` owns `:5037` and shared USB devices; later users automatically join and only see shared USB plus **their own** paired remotes. Pair codes never leave the user's process. Details: [docs/multi-user-design.md](docs/multi-user-design.md).

## Device host (USB machine)

```bash
adb start-server
adb devices
# pair code is printed at startup (or set ADB_PROXY_PAIR_CODE / --pair-code)
cargo run --bin adb-proxy -- --listen 0.0.0.0:5038 --target 127.0.0.1:5037
```

Or with a release binary:

```bash
adb-proxy --listen 0.0.0.0:5038 --target 127.0.0.1:5037
# optional fixed code for reconnects:
# ADB_PROXY_PAIR_CODE=ABCD1234 adb-proxy ...
```

## Client (your machine)

Stop any local adb server that already owns `:5037`, then pair and start the hub:

```bash
adb kill-server

# Pair with a remote proxy (writes config to the default location —
#   ~/.config/adb-hub/config.toml on Linux/macOS,
#   %APPDATA%\adb-hub\config.toml on Windows)
adb-hub pair 192.168.1.10:5038 ABCD1234 --name office
adb-hub pair 192.168.1.11:5038 EFGH5678 --name lab

# Start hub (same command for one user or many users on a Linux server)
adb-hub --daemon
# equivalent:
# adb-hub
```

Then use stock adb:

```bash
adb devices
```

You can still pass backends on the CLI (without a pair code they cannot talk to an auth-gated proxy):

```bash
adb-hub --backend office=192.168.1.10:5038
adb-hub --config ~/.config/adb-hub/config.toml
```

Example config after pairing:

```toml
listen = "127.0.0.1:5037"
poll_interval_ms = 1000
include_local = true
local_adb_port = 5039

[[backend]]
name = "office"
addr = "192.168.1.10:5038"
pair_code = "ABCD1234"

[[backend]]
name = "lab"
addr = "192.168.1.11:5038"
pair_code = "EFGH5678"
```

By default `adb-hub` also starts a real local `adb` server on `local_adb_port` (5039), frees `:5037` for itself, and aggregates local USB devices as backend `local` together with remotes. Use `--no-local` to disable. The local backend does not use pair-code auth.

Then use the original `adb` as usual (no `-H` / `-P`, no PATH wrapper):

```bash
adb devices
adb -s <serial> shell
adb install app.apk
```

If two backends expose the same serial, the hub rewrites them to `name:serial` (for example `office:ABC123`).

Legacy `~/.adbproxy` (`host=` / `port=`) is still loaded when the TOML config is missing.

## Setup helper

[`adb_setup.sh`](adb_setup.sh) (Linux / macOS) and [`adb_setup.ps1`](adb_setup.ps1) (Windows) download a GitHub Release for your OS/arch (latest by default), install `adb-hub` and `adb-proxy` into `~/.local/bin`, then write the client TOML config. They do not replace the official `adb` binary.

### Linux / macOS

```bash
curl -fsSL https://raw.githubusercontent.com/Ken-u/adbproxy-rs/main/adb_setup.sh | bash
```

Useful flags:

```bash
bash adb_setup.sh --install                    # download + install only
bash adb_setup.sh --install --version 0.4.4    # pin a release (also accepts v0.4.4)
bash adb_setup.sh --config                     # config only
bash adb_setup.sh --uninstall-wrapper          # remove legacy PATH wrapper
```

Install directory override: `ADB_PROXY_INSTALL_DIR=~/bin`.

### Windows (PowerShell)

```powershell
# Run from a PowerShell terminal (Network access required for the one-time download)
.\adb_setup.ps1
```

Or inline:

```powershell
irm https://raw.githubusercontent.com/Ken-u/adbproxy-rs/main/adb_setup.ps1 | iex
```

Useful flags:

```powershell
.\adb_setup.ps1 -Install                    # download + install only
.\adb_setup.ps1 -Install -Version 0.4.4     # pin a release (also accepts v0.4.4)
.\adb_setup.ps1 -Config                     # interactive config only
.\adb_setup.ps1 -UninstallWrapper           # remove legacy PATH wrapper
```

Install directory override: `$env:ADB_PROXY_INSTALL_DIR = "$HOME\bin"`.

> **Note** — Windows config is written to `%APPDATA%\adb-hub\config.toml`. If a config from the previous location (`%USERPROFILE%\.config\adb-hub\config.toml`) is found, `adb-hub` loads it automatically. Windows uses `tar` (bundled since Windows 10 1803) to extract the archive, and if the install directory is not on `PATH` the script offers to append it to the user-level `PATH`.

## Binary usage

### adb-proxy (device host)

```bash
adb-proxy \
  --listen 0.0.0.0:5038 \
  --target 127.0.0.1:5037 \
  --pair-code ABCD1234 \
  --log-level info
```

Env: `ADB_PROXY_LISTEN`, `ADB_PROXY_TARGET`, `ADB_PROXY_PAIR_CODE`, `ADB_PROXY_CONFIG`, `ADB_PROXY_LOG`.

If `--pair-code` / `ADB_PROXY_PAIR_CODE` is omitted, a random 8-character `A-Z0-9` code is generated and logged at startup.

Manage which USB devices this host exposes (default: all enabled):

```bash
adb-proxy device list
adb-proxy device disable A0001XX
adb-proxy device enable A0002XXX
```

Policy is stored in `~/.config/adb-proxy/config.toml` (Windows: `%APPDATA%\adb-proxy\config.toml`). Disabled devices are omitted from `host:devices` / `track-devices` and cannot be transported. Changes apply without restarting the proxy.

```toml
[[device]]
serial = "A0001XX"
enabled = false
```

### adb-hub (client)

```bash
# Pair once (per user)
adb-hub pair 192.168.1.10:5038 ABCD1234 --name office
adb-hub list
adb-hub unpair office

# Run hub — same command for one laptop or many users on a Linux server
adb-hub --daemon
# equivalent:
# adb-hub
```

On Linux, the first process owns `:5037` and shared USB devices; later users
running the same command automatically join and only register their own paired
remotes. On macOS/Windows the same CLI runs a classic in-process aggregator.

Env: `ADB_HUB_LISTEN`, `ADB_HUB_CONFIG`, `ADB_HUB_POLL_MS`, `ADB_HUB_LOG`.

Device and node enable state (public serial for devices; backend name for nodes):

```bash
adb-hub device list
adb-hub device disable office:A0001XX
adb-hub device enable A0002XXX

adb-hub node list
adb-hub node disable office
adb-hub node enable office
```

When a node is disabled, none of its devices appear in the aggregated list. Omit `enabled` or set `enabled = true` to keep the default (enabled).

```toml
[[backend]]
name = "office"
addr = "192.168.1.10:5038"
pair_code = "ABCD1234"
enabled = false

[[device]]
serial = "lab:ABC123"
enabled = false
```

`adb-hubd` is a compatibility alias for `adb-hub --daemon`.
## Release Artifacts

GitHub Actions builds downloadable archives:

- `adb-proxy-linux-x86_64-musl.tar.gz`
- `adb-proxy-macos-aarch64.tar.gz`
- `adb-proxy-macos-x86_64.tar.gz`
- `adb-proxy-windows-x86_64.tar.gz`

Each archive includes `adb-proxy`, `adb-hub`, and `adb-hubd` (alias of `adb-hub --daemon`).

## Automatic Releases

Releases are driven by `Cargo.toml` on pushes to `main`:

1. Update `package.version`, for example `0.2.4`.
2. Push to `main` (do **not** push a `v*` tag yourself).
3. GitHub Actions builds all platforms.
4. If release `v0.2.4` does not already exist, the workflow creates tag `v0.2.4`, creates a GitHub Release, and uploads the archives.

Tag pushes no longer trigger CI (avoids duplicate runs when the workflow creates the tag).

## Development

```bash
cargo test
cargo build --bins
cargo run --bin adb-proxy -- --listen 0.0.0.0:5038 --target 127.0.0.1:5037 --pair-code ABCD1234
cargo run --bin adb-hub -- pair 127.0.0.1:5038 ABCD1234 --name mock
cargo run --bin adb-hub -- --daemon
```
## Scope

Implemented:

- TCP `adb-proxy` with pair-code auth on every connection (device host)
- Unified `adb-hub` / `adb-hub --daemon` for stock `adb` on `:5037`
- On Linux: shared listener + per-user backends automatically (no separate agent command needed)
- Elsewhere: same CLI runs the classic in-process aggregator
- `adb-hub pair|unpair|list` persists backends + pair codes (owner-only config mode on Unix)
- Hub rejects / skips paired proxies below the required `adb-proxy` version (`proxy:version`)
- Auto-starts local `adb` on a side port and aggregates USB devices as `local`
- Multi-backend device list merge + serial conflict rewrite
- Opaque forward of non-list host services (`features`, `tport`, `transport`, …) to the owning/default backend
- `host:version`, `host:devices` / `devices-l`, `host:track-devices`, `host:transport:*`, `host:transport-any`, `host:kill`, `host-serial:*` forwarding
- TOML config + legacy `~/.adbproxy` + CLI `--backend`
- Per-device enable/disable on proxy and hub (`device list|enable|disable`)
- Per-node enable/disable on hub (`node list|enable|disable`)

Not in this phase:

- LAN auto-discovery
- Sharing `:5037` with a separately started default adb server (hub relocates local adb to `local_adb_port`)
- Device lease / locking for shared USB devices across users